/**
 * @GameDraw.js 
 *
 * GameDraw function is placed in the game loop.
 * It is responsbile for all the drawing actions.
 * 
 * @function        GameDraw - Responsbile for all the drawing actions
 * @author          Ali Kutluozen     
 */

var GameDraw = function () {

    'use strict';

    // Draw the background of the level first
    Levels.draw();

    // Draw game objects that have draw methods
    for (let i = 0, len = Levels.currentLevel().objectsList.length; i < len; i++) {
        // If there is a camera present, draw objects only when they are in the view
        if (Levels.currentLevel().camera) {
            if (Video.isObjectInView(Levels.currentLevel().objectsList[i])) {
                Levels.currentLevel().objectsList[i].draw();
            }
        } else Levels.currentLevel().objectsList[i].draw();
    }

    // Draw the HUD on top of everything
    Video.drawText(Globals.score, "Impact", 24, "white", Video.getScreenWidth() / 2, 0, "center", false);

    // Handle game over screen
    if (Engine.gameStatus() === false) {
        Video.fade('black', 0, 0.75, 50, function () { 
            Engine.pause(true);
            Video.drawText("GAME OVER", "Impact", 64, "white", Video.getScreenWidth() / 2, Video.getScreenHeight() / 2 - 24, "center");
        });
    }

    // Let the video engine render the screen
    Video.render();
}