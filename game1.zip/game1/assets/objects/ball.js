function Ball(x, y, z, width, height, name, tag, controlled) {
    Entity.apply(this, arguments); // Apply the inherited properties
    this.img = Loader.getFile('sprites'); // Load the object image

    // Define object specific properties
    this.speedX = 2;
    this.speedY = 2;
    this.controlled = true;

    this.whatIsAroundMe = []; // An empty list of colliding surrounding objects

    // Define collision area if one is needed
    this.coll = new Physics.CircleCollision(x, y, z, width);
}

// Establish the inheritance
Ball.prototype = new Entity();

// Define object methods
Ball.prototype.draw = function () {
    this.ctx.drawImage(this.img, 128, 32, 24, 24, this.x, this.y, this.width, this.height);
}

Ball.prototype.update = function () {
    // Always keep an updated list of what is around
    this.whatIsAroundMe = Physics.searchAround(this, this.whatIsAroundMe);

    // Save the previous spot
    var prevX = this.coll.x - this.speedX;
    var prevY = this.coll.y - this.speedY;

    // If the object is supposed to respond to more than one instance, use a for loop
    for (var i = 0; i < this.whatIsAroundMe.length; i++) {
        var other = this.whatIsAroundMe[i];

        if (other.name === 'box') {
            // Collision from left or right
            if (prevX < other.coll.x || prevX > other.coll.x + other.coll.width) {
                this.speedX *= -1;
            }

            // Collision from top or bottom
            if (prevY < other.coll.y || prevY > other.coll.y + other.coll.height) {
                this.speedY *= -1;
            }
            break;
        }

        if (other.name === 'pad') {
            if (prevY < other.coll.y + other.coll.height) {
                this.speedY *= -1.05; // Ball gets gradually faster
                this.speedY = GameMath.clamp(this.speedY, -5, 5); // There is a limit to balls vertical speed
                this.speedX = GameMath.clamp(((this.coll.x - (other.coll.x + other.coll.width / 2)) * 0.2), -5, 5);
                break;
            }
        }

        if (other.name === 'wall') {
            // Collision from right
            if (prevX + this.coll.r <= other.coll.x) {
                this.speedX = -Math.abs(this.speedX);
            }

            // Collision from left
            if (prevX - this.coll.r >= other.coll.x + other.coll.width) {
                this.speedX = Math.abs(this.speedX);
            }

            // Collision from top or bottom
            if (prevY + this.coll.r <= other.coll.y || prevY - this.coll.r >= other.coll.y + other.coll.height) {
                this.speedY *= -1;
            }
            break;
        }
    }

    if (this.coll.y > Levels.currentLevel().height) {
        Engine.gameStatus('over');
        Globals.life--;
    }

    this.x += this.speedX;
    this.y += this.speedY;

    // Always update the collision area position and center it based on the object position
    this.coll.update(this.x + this.width / 2, this.y + this.height / 2);
}

Ball.prototype.handleMouseMovement = function (input) {
    this.movement = input;
}

Ball.prototype.handleKeyDown = function (input) {
    if (input === 39) {
        this.speedX = 1;
    }
    if (input === 37) {
        this.speedX = -1;
    }
    if (input === 38) {
        this.speedY = -1;
    }
    if (input === 40) {
        this.speedY = 1;
    }
    if (input === 32 && !this.isJumping && !this.isFalling) {
        this.isJumping = true;
        this.yVelocity = -this.jumpSpeed;
    }
}

Ball.prototype.handleKeyUp = function (input) {
    if (input === 39) {
        this.speedX = 0;
    }
    if (input === 37) {
        this.speedX = 0;
    }
    if (input === 38) {
        this.speedY = 0;
    }
    if (input === 40) {
        this.speedY = 0;
    }
}