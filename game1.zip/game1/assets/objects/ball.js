function Ball(x, y, z, width, height, name, tag, controlled) {
    Entity.apply(this, arguments); // Apply the inherited properties
    this.img = Loader.getFile('sprites'); // Load the object image

    // Define object specific properties
    // x 4.18, y 2 to test bottom right
    // x -4.18 y -1.05 test top right with a box
    // x -1.24 y 2 test bottom left
    // x -3 y 1.25 test to walls on left
    // x 4.85 y 1 test to walls on right
    // x -1.34 y -2 test wall top right
    this.speedX = 4.18;
    this.speedY =2;
    this.controlled = true;

    // Define collision area if one is needed
    this.coll = new Physics.AABBCollision(x, y, z, width, height);
}

// Establish the inheritance
Ball.prototype = new Entity();

// Define object methods
Ball.prototype.draw = function () {
    this.ctx.drawImage(this.img, 128, 32, 24, 24, this.x, this.y, this.width, this.height);
    this.coll.draw();
}

Ball.prototype.update = function () {
    // Save the previous spot
    let prevX = this.x - this.speedX,
        prevY = this.y - this.speedY;


    // Check around
    if (other = Physics.checkCollision(this)) {
        if (other.name === 'box') {
            // Collision from left
            if (prevX <= other.coll.x) {
                this.speedX *= -1;
            }

            // Collision from right
            if (prevX >= other.coll.x + other.coll.width) {
                this.speedX *= -1;
            }

            // Collision from top
            if (prevY <= other.coll.y) {
                this.speedY *= -1;
            }

            // Collision from bottom
            if (prevY >= other.coll.y + other.coll.height) {
                this.speedY *= -1;
            }

            // Send away the broken box object
            other.y = -100;
            // Increment the score!
            Globals.score++;
        }

        if (other.name === 'pad') {
            if (prevY < other.coll.y + other.coll.height) {
                this.speedY *= -1.05; // Ball gets gradually faster
                this.speedY = GameMath.clamp(this.speedY, -5, 5); // There is a limit to balls vertical speed
                this.speedX = GameMath.clamp(((this.coll.x + this.coll.width / 2 - (other.coll.x + other.coll.width / 2)) * 0.1), -5, 5);
            }
        }

        if (other.name === 'wall') {
            // Collision from the bottom
            if (prevY >= other.coll.y + other.coll.height) {
                this.y = prevY;
                this.speedY *= -1;
            }

            // Collision from left or right
            if (prevX <= other.coll.x || prevX >= other.coll.x + other.coll.width) {
                this.x = prevX;
                this.speedX *= -1;
            }
        }
    }

    if (this.coll.y > Levels.currentLevel().height) {
        Engine.gameStatus('over');
        Globals.life--;
    }

    this.x += this.speedX;
    this.y += this.speedY;

    // Always update the collision area position and center it based on the object position
    this.coll.update(this.x, this.y);
}

Ball.prototype.handleMouseMovement = function (input) {
    this.movement = input;
}

Ball.prototype.handleKeyDown = function (input) {
    if (input === 39) {
        this.speedX = 1;
    }
    if (input === 37) {
        this.speedX = -1;
    }
    if (input === 38) {
        this.speedY = -1;
    }
    if (input === 40) {
        this.speedY = 1;
    }
    if (input === 32 && !this.isJumping && !this.isFalling) {
        this.isJumping = true;
        this.yVelocity = -this.jumpSpeed;
    }
}

Ball.prototype.handleKeyUp = function (input) {
    if (input === 39) {
        this.speedX = 0;
    }
    if (input === 37) {
        this.speedX = 0;
    }
    if (input === 38) {
        this.speedY = 0;
    }
    if (input === 40) {
        this.speedY = 0;
    }
}