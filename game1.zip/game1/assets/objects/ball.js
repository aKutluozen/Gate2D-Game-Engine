function Ball(x, y, z, width, height, name, tag, controlled) {
    Entity.apply(this, arguments); // Apply the inherited properties
    this.img = Loader.getFile('imgBall'); // Load the object image

    // Define object specific properties
    this.speedX = 1;
    this.speedY = 1;

    this.whatIsAroundMe = []; // An empty list of colliding surrounding objects

    // Define collision area if one is needed
    this.coll = new Physics.CircleCollision(x, y, z, width);

}

// Establish the inheritance
Ball.prototype = new Entity();

// Define object methods
Ball.prototype.draw = function () {
    this.ctx.drawImage(this.img, this.x, this.y, this.width, this.height);
}

Ball.prototype.update = function () {
    // Always keep an updated list of what is around
    this.whatIsAroundMe = Physics.searchAround(this, this.whatIsAroundMe);

    // Save the previous spot
    var prevX = this.coll.x - this.speedX;
    var prevY = this.coll.y - this.speedY;

    // If the object is supposed to respond to more than one instance, use a for loop
    for (var i = 0; i < this.whatIsAroundMe.length; i++) {
        var other = this.whatIsAroundMe[i];

        if (other.name === 'box') {
            // Collision from left or right
            if (prevX + this.coll.r <= other.coll.x || prevX - this.coll.r >= other.coll.x + other.coll.width) {
                this.speedX *= -1;
            }

            // Collision from top or bottom
            if (prevY + this.coll.r <= other.coll.y || prevY - this.coll.r >= other.coll.y + other.coll.height) {
                this.speedY *= -1;
            }

            // Send the brick away
            other.x = -100;
            // Increase the score
            Globals.score++;

        } 
        if (other.name === 'pad') {
            this.speedY *= -1;
            this.speedX = (this.coll.x - (other.coll.x + other.coll.width / 2)) * 0.2;
        } 
        if (other.name === 'wall') {
            
            // Collision from right
            if (prevX + this.coll.r <= other.coll.x) {
                this.speedX *= -1;
            }

            // Collision from left
            if (prevX - this.coll.r >= other.coll.x + other.coll.width) {
                this.speedX *= -1;
            }

            // Collision from top or bottom
            if (prevY + this.coll.r <= other.coll.y || prevY - this.coll.r >= other.coll.y + other.coll.height) {
                this.speedY *= -1;
            }
        }
    }

    this.x += this.speedX;
    this.y += this.speedY;

    // Always update the collision area position and center it based on the object position
    this.coll.update(this.x + this.width / 2, this.y + this.height / 2);
}