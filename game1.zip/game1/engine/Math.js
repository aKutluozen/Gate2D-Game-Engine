/**
 * Math.js
 * 
 * @summary         Provides a basic math functions
 * @module          GameMath
 * @author          Ali Kutluozen
 * @version         0.1.0
 */

var GameMath = (function () {

    'use strict';

    let numAnimFrom,
        numAnimTo;

    return {
        /**
         * Returns the distance between 2 points
         * 
         * @param {number}  a - Length of side a
         * @param {number}  b - Length of side b
         * @returns {number}
         */
        hypotenuse: function (a, b) {
            return Math.sqrt(a * a + b * b);
        },

        /**
         * Returns a number that is limited between 2 numbers
         * 
         * @param {number}  num - Number to be clamped
         * @param {number}  min - Minimum value allowed
         * @param {number}  max - Maximum value allowed
         * @returns {number}
         */
        clamp: function (num, min, max) {
            return Math.min(Math.max(min, num), max);
        },

        animateNumber: function (from, to, speed) {
            
        }
    }
}());
